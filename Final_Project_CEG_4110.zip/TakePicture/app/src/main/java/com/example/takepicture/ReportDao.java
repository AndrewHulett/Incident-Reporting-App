package com.example.takepicture;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Dao
public interface ReportDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Report report);

    @Query("SELECT * FROM report")
    LiveData<List<Report>> loadAllReports();

    @Query("SELECT uid FROM report")
    LiveData<List<Long>> loadUIDs();

    @Query("SELECT * FROM report WHERE UID = :uid")
    LiveData<Report> findReportByUID(Long uid);
}

