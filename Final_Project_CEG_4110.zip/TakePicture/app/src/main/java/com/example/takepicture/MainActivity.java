package com.example.takepicture;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    protected enum DataHolder {
        INSTANCE;

        private ArrayList<Bitmap> mBitmapList;
        private byte[] mImagesArray;

        public static boolean hasData() {
            return INSTANCE.mBitmapList != null;
        }

        public static void setBitmaps(final ArrayList<Bitmap> bitmaps) {
            INSTANCE.mBitmapList = bitmaps;
        }

        public static ArrayList<Bitmap> getBitmaps() {
            final ArrayList<Bitmap> returnList = INSTANCE.mBitmapList;
            INSTANCE.mBitmapList = null;
            return returnList;
        }

        public static void setImages(final byte[] images) {
            INSTANCE.mImagesArray = images;
        }

        public static byte[] getImages() {
            final byte[] returnArray = INSTANCE.mImagesArray;
            INSTANCE.mImagesArray = null;
            return returnArray;
        }
    }

    private ViewModel viewModel;
    public static final String EXTRA_REPORT = "REPORT";
    public static final String EXTRA_WEATHER = "WEATHER";
    public Report queryReturn = new Report();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView ReportList = findViewById(R.id.reportlist);
        ArrayList<Date> DateArr = new ArrayList<Date>();
        final ArrayAdapter adapter = new ArrayAdapter<Integer>(this, android.R.layout.simple_list_item_1);
        ReportList.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(ViewModel.class);

        viewModel.getAllUIDs().observe(this, new Observer<List<Long>>() {
            @Override
            public void onChanged(@Nullable final List<Long> uids){
                DateArr.clear();
                for (int i = 0; i<uids.size(); i++){
                    DateArr.add(new Date(uids.get(i)));
                }
                adapter.clear();
                adapter.addAll(DateArr);
            }
        });

        ArrayList<Report> allReports = new ArrayList<Report>();
        viewModel.getAllReports().observe(this, new Observer<List<Report>>() {
            @Override
            public void onChanged(@Nullable final List<Report> uids){
                allReports.clear();
                allReports.addAll(uids);
            }
        });

        ReportList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Date date = (Date)adapter.getItem(position);
                Long uid = date.getTime();
                Report foundReport = new Report();
                for(int i = 0; i<allReports.size(); i++){
                    if (uid.longValue() == allReports.get(i).UID.longValue()){
                        foundReport = allReports.get(i);
                        MainActivity.DataHolder.setImages(foundReport.images);
                        Report newReport = foundReport.DeepCopy(foundReport);

                        Intent intent = new Intent(MainActivity.this, ViewReportActivity.class);
                        intent.putExtra(EXTRA_REPORT, newReport);
                        intent.putExtra(EXTRA_WEATHER, foundReport.weather.toString());
                        startActivity(intent);
                        break;
                    }
                }
            }
        });
    }

    /** Called when the user taps the Create new report button */
    public void createReport(View view) {
        Intent intent = new Intent(this, PhotoActivity.class);
        startActivity(intent);
    }

}