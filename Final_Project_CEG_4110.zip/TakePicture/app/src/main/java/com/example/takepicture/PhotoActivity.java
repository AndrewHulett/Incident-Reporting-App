package com.example.takepicture;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.graphics.Bitmap;
        import android.os.Bundle;
        import android.provider.MediaStore;
        import android.view.View;
        import android.widget.ImageView;
        import android.widget.TableLayout;
        import android.widget.TableRow;
        import java.util.ArrayList;

public class PhotoActivity extends AppCompatActivity {

    public static final String EXTRA_IMG_ARR = "IMAGES";
    private TableLayout table;
    private int currColumn = 0;
    private int currRow = 0;
    private static final int REQUEST_IMAGE_CAPTURE = 101;
    private static final int GET_REPORT_INFO = 0;
    public ArrayList<Bitmap> Images = new ArrayList<Bitmap>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);
        table = findViewById(R.id.tableLayout);
    }

    public void takePicture(View view) {
        Intent imageTakeIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if(imageTakeIntent.resolveActivity(getPackageManager())!=null){
            startActivityForResult(imageTakeIntent,REQUEST_IMAGE_CAPTURE);
        }
    }

    public void goToInputInfo(View view){
        Intent intent = new Intent(this, InputInfoActivity.class);
        MainActivity.DataHolder.setBitmaps(Images);
        startActivityForResult(intent, GET_REPORT_INFO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GET_REPORT_INFO && resultCode == RESULT_OK) {
            finish();
        }

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            Images.add(imageBitmap);

            ImageView im = new ImageView (this);
            im.setImageBitmap(imageBitmap);
            im.setPadding(0, 0, 0, 0); //padding in each image if needed

            if(currColumn<3 && currColumn >0){//add new column to current row
                TableRow row = (TableRow)table.getChildAt(currRow);
                row.addView(im, 350,440);//image, width, height
                currColumn++;
            }
            else{//add new row
                if ( currColumn != 0){
                    currRow++;
                }
                currColumn = 1;
                TableRow newRow = new TableRow(this);
                newRow.addView(im, 350,440);//image, width, height
                table.addView(newRow);
            }
        }
    }
}
