package com.example.takepicture;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.sql.Date;
import java.util.List;

public class ViewModel extends AndroidViewModel {

    private ReportRepository rep;
    private LiveData<List<Report>> reports;
    private LiveData<List<Long>> uids;

    public ViewModel(Application application){
        super(application);
        rep = new ReportRepository(application);
        reports =  rep.getAllReports();
        uids = rep.getallUids();
    }

    LiveData<List<Report>> getAllReports() {
        return reports;
    }

    LiveData<List<Long>> getAllUIDs() {
        return uids;
    }

    LiveData<Report> getReportByUID(Long uid){
        return rep.getReportByUID(uid);
    }
}
