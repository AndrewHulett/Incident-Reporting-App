package com.example.takepicture;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.ColumnInfo;
import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import org.json.JSONObject;

import java.sql.Blob;
import java.sql.Date;

@Entity
public class Report implements Parcelable {
    @PrimaryKey
    public Long UID;

    public JSONObject weather;

    public String driverName;
    public String accidentType;
    public String otherDrivers;
    public String atFault;
    public String otherInfo;

    public byte[] images;
    public int[] sizes;

    public Report(){

    }

    protected Report(Parcel in) {
        if (in.readByte() == 0) {
            UID = null;
        } else {
            UID = in.readLong();
        }
        driverName = in.readString();
        accidentType = in.readString();
        otherDrivers = in.readString();
        atFault = in.readString();
        otherInfo = in.readString();
        images = in.createByteArray();
        sizes = in.createIntArray();
    }

    public static final Creator<Report> CREATOR = new Creator<Report>() {
        @Override
        public Report createFromParcel(Parcel in) {
            return new Report(in);
        }

        @Override
        public Report[] newArray(int size) {
            return new Report[size];
        }
    };

    public Report DeepCopy(Report original){
        Report newRep = new Report();
        newRep.UID = original.UID;
        newRep.driverName = original.driverName;
        newRep.accidentType = original.accidentType;
        newRep.otherDrivers = original.otherDrivers;
        newRep.atFault = original.atFault;
        newRep.otherInfo = original.otherInfo;
        newRep.sizes = original.sizes;
        newRep.weather = original.weather;
        return newRep;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (UID == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeLong(UID);
        }
        dest.writeString(driverName);
        dest.writeString(accidentType);
        dest.writeString(otherDrivers);
        dest.writeString(atFault);
        dest.writeString(otherInfo);
        dest.writeByteArray(images);
        dest.writeIntArray(sizes);
    }
}
