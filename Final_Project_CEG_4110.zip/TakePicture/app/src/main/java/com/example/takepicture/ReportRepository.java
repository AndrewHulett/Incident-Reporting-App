package com.example.takepicture;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.sql.Date;
import java.util.List;

public class ReportRepository {
    private ReportDao mReportDao;
    private LiveData<List<Report>> reports;
    private LiveData<List<Long>> uids;


    ReportRepository(Application application){
        ReportDatabase db = ReportDatabase.getDatabase(application);
        mReportDao = db.ReportDao();
        reports = mReportDao.loadAllReports();
        uids = mReportDao.loadUIDs();
    }

    void insert(Report report){
        ReportDatabase.databaseWriteExecutor.execute(() -> {
            mReportDao.insert(report);
        });
    }

    LiveData<List<Report>> getAllReports() {
        return reports;
    }

    LiveData<List<Long>> getallUids(){
        return uids;
    }

    LiveData<Report> getReportByUID(Long uid){
        return mReportDao.findReportByUID(uid);
    }
}
