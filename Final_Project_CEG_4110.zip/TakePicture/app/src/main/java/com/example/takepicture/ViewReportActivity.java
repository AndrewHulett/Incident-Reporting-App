package com.example.takepicture;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Html;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.sql.Date;
import java.util.Arrays;

public class ViewReportActivity extends AppCompatActivity {

    Report report = new Report();
    private int currColumn = 0;
    private int currRow = 0;
    private double lat;
    private double lon;
    private double temp;
    private String sky;
    private String skyDesc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_report);
        Intent intent = getIntent();
        report = intent.getParcelableExtra(MainActivity.EXTRA_REPORT);
        report.images = MainActivity.DataHolder.getImages();
        String weatherStr = intent.getStringExtra(MainActivity.EXTRA_WEATHER);
        try {
            report.weather = new JSONObject(weatherStr);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        GetWeatherFromJSON(report.weather);
        PopulateTextViews();
        populateImageTable();

    }

    public void GetWeatherFromJSON(JSONObject json){
        try {
            JSONObject coords = json.getJSONObject("coord");
            JSONArray weatherConds = json.getJSONArray("weather");
            JSONObject weatherConds2 = weatherConds.getJSONObject(0);
            JSONObject temperature = json.getJSONObject("main");

            temp = temperature.getDouble("temp");
            sky = weatherConds2.getString("main");
            skyDesc = weatherConds2.getString("description");
            lat = coords.getDouble("lat");
            lon = coords.getDouble("lon");

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"Weather info could not be loaded", Toast.LENGTH_LONG).show();
        }


    }

    public void PopulateTextViews(){
        TextView uidText = findViewById(R.id.uidText);
        TextView yourName = findViewById(R.id.yourName);
        TextView accidentType = findViewById(R.id.accidentType);
        TextView otherDrivers = findViewById(R.id.otherDrivers);
        TextView atFault = findViewById(R.id.atFault);
        TextView otherInfo = findViewById(R.id.otherInfo);
        TextView location = findViewById(R.id.location);
        TextView temperature = findViewById(R.id.temp);
        TextView skycond = findViewById(R.id.sky);

        Date date = new Date(report.UID);
        String tempString = "<b>"+ date.toString() + "</b>";
        uidText.setText(Html.fromHtml(tempString));

        tempString = "<b>"+ "Driver Name:  " + "</b>" + report.driverName;
        yourName.setText(Html.fromHtml(tempString));

        tempString = "<b>"+ "Accident Type:  " + "</b>" + report.accidentType;
        accidentType.setText(Html.fromHtml(tempString));

        tempString = "<b>"+ "Other Drivers:  " + "</b>" + report.otherDrivers;
        otherDrivers.setText(Html.fromHtml(tempString));

        tempString = "<b>"+ "Driver at Fault:  " + "</b>" + report.atFault;
        atFault.setText(Html.fromHtml(tempString));

        tempString = "<b>"+ "Other Information:  " + "</b><br/>" + report.otherInfo;
        otherInfo.setText(Html.fromHtml(tempString));

        tempString = "<b>"+ "Latitude: " + "</b>" + lat + "<b>"+ "  Longitude: " + "</b>" + lon;
        location.setText(Html.fromHtml(tempString));

        tempString = "<b>"+ "Temperature: " + "</b>" + temp + " Kelvin";
        temperature.setText(Html.fromHtml(tempString));

        tempString = "<b>"+ "Sky Conditions: " + "</b>" + sky + ";  " + skyDesc;
        skycond.setText(Html.fromHtml(tempString));


    }

    public  Bitmap ByteToBmp(byte[] byteArr){
        Bitmap bmp = BitmapFactory.decodeByteArray(byteArr, 0, byteArr.length);
        if (bmp==null){
            System.out.println("here");
        }
        return bmp;
    }

    public void populateImageTable() {
        TableLayout table = findViewById(R.id.table);
        int numImages=0;
        for(int i=0; i<=8; i++){//get number of images
            if(report.sizes[i]!=0){
                numImages++;
            }
        }

        int imgStart=0;
        int imgEnd= report.sizes[0];

        for(int i=0; i<numImages; i++){
            byte[] tempArr = Arrays.copyOfRange(report.images, imgStart, imgEnd);
            ImageView im = new ImageView (this);
            im.setImageBitmap(ByteToBmp(tempArr));
            im.setPadding(0, 0, 0, 0); //padding in each image if needed

            if(currColumn<3 && currColumn >0){//add new column to current row
                TableRow row = (TableRow)table.getChildAt(currRow);
                row.addView(im, 350,440);//image, width, height
                currColumn++;
            }
            else{//add new row
                if ( currColumn != 0){
                    currRow++;
                }
                currColumn = 1;
                TableRow newRow = new TableRow(this);
                newRow.addView(im, 350,440);//image, width, height
                table.addView(newRow);
            }
            imgStart = imgEnd;
            if(i<numImages-1){
                imgEnd += report.sizes[i+1];
            }

            if(imgEnd > report.images.length)
            {
                imgEnd = report.images.length;
            }
        }
    }
}
