package com.example.takepicture;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Calendar;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.location.Location;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class InputInfoActivity extends AppCompatActivity {

    public Report report = new Report();
    ArrayList<Bitmap> images = new ArrayList<Bitmap>();
    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_info);

        EditText editText = (EditText)findViewById(R.id.otherInfo);
        editText.setGravity(Gravity.TOP);

        Intent intent = getIntent();
        images = intent.getParcelableArrayListExtra(PhotoActivity.EXTRA_IMG_ARR);
        images = MainActivity.DataHolder.getBitmaps();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            // Logic to handle location object
                            try {
                                getWeatherConditions(location.getLatitude(),location.getLongitude());
                            } catch (IOException e) {
                                e.printStackTrace();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
    }


    /** Called when the user taps the done button */
    public void saveReport(View view) {
        if(report.weather == null){
            Toast.makeText(getApplicationContext(),"Weather info could not be found, does the app have location permission?", Toast.LENGTH_LONG).show();
            return;
        }
        if(!getTextFields()){
            Toast.makeText(getApplicationContext(),"Please fill out all text fields", Toast.LENGTH_LONG).show();
            return;
        }
        report.UID = Calendar.getInstance().getTime().getTime();

        PrepBitmapsForSend(images);

        //Save report to database
        ReportDatabase db = ReportDatabase.getDatabase(this);
        ReportDao mReportDao = db.ReportDao();
        ReportDatabase.databaseWriteExecutor.execute(() -> {
            mReportDao.insert(report);
        });
        setResult(RESULT_OK);
        finish();
    }

    public boolean getTextFields(){
        EditText yourName = (EditText)findViewById(R.id.yourName);
        EditText accidentType = (EditText)findViewById(R.id.accidentType);
        EditText otherDrivers = (EditText)findViewById(R.id.otherDrivers);
        EditText atFault = (EditText)findViewById(R.id.atFault);
        EditText otherInfo = (EditText)findViewById(R.id.otherInfo);

        String temp = yourName.getText().toString();

        if( (yourName.getText().toString().equals("") ) || (accidentType.getText().toString().equals("")) || (otherDrivers.getText().toString().equals(""))
                || (atFault.getText().toString().equals("")) || (otherInfo.getText().toString().equals(""))){
            return false;
        }
        else{
            report.driverName = yourName.getText().toString();
            report.accidentType = accidentType.getText().toString();
            report.otherDrivers = otherDrivers.getText().toString();
            report.atFault = atFault.getText().toString();
            report.otherInfo = otherInfo.getText().toString();
            return true;
        }
    }

    public byte[] bmpToByte(Bitmap bmp){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] arr = stream.toByteArray();
        return arr;
    }

    public void PrepBitmapsForSend(ArrayList<Bitmap> Bitmaps)
    {
        byte[][] allImages = new byte[9][110000];
        int[] sizes = new int[9];
        Arrays.fill(sizes, 0);
        for (int i = 0; i< Bitmaps.size() && i<9; i++){
            byte[] temp = bmpToByte(Bitmaps.get(i));
            sizes[i]=temp.length;
            allImages[i] = temp;
        }

        byte[] returnArray = new byte[sizes[0] + sizes[1] + sizes[2] + sizes[3] + sizes[4] + sizes[5] + sizes[6] + sizes[7] +sizes[8]];

        ByteBuffer buff = ByteBuffer.wrap(returnArray);
        for (int i = 0; i<Bitmaps.size() && i<9; i++){
            buff.put(allImages[i]);
        }

        report.images = buff.array();//TODO: switch this back?
        report.sizes = sizes;
    }

    private JSONObject getWeatherConditions(double lat, double lon) throws IOException, JSONException {
        String api_key = "d8b66a25b42bbd41ee0695a7973d45d1";
        String api_url_string = "https://api.openweathermap.org/data/2.5/weather?lat=" + lat + "&lon=" + lon + "&APIKEY=" + api_key;
        RequestQueue queue = Volley.newRequestQueue(this);
        JSONObject weather_info = new JSONObject();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, api_url_string, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                       // do stuff
                        System.out.println(response.toString());
                        report.weather = response;
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error
                    }
                });
        queue.add(jsonObjectRequest);

        return weather_info;
    }
}
