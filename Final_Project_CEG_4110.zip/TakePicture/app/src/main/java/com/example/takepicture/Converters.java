package com.example.takepicture;

import androidx.room.TypeConverter;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.sql.Date;
import java.util.ArrayList;

public class Converters {
    //JSON
    @TypeConverter
    public static String fromJSON(JSONObject json) {
        return json.toString();
    }

    @TypeConverter
    public static JSONObject fromString3(String str) {
        JSONObject json = null;
        try {
            json = new JSONObject(str);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

    //int array
    @TypeConverter
    public static int[] fromString2(String value) {
        Type listType = new TypeToken<int[]>() {}.getType();
        return new Gson().fromJson(value, listType);
    }

    @TypeConverter
    public static String fromIntArray(int[] arr) {
        Gson gson = new Gson();
        String json = gson.toJson(arr);
        return json;
    }
}